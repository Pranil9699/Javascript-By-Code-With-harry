
setInterval(()=>{
  const c = new Date();

  document.getElementById("HourDiv").innerHTML=c.getHours();
  document.getElementById("MinuteDiv").innerHTML=c.getMinutes();
  document.getElementById("SecondDiv").innerHTML=c.getSeconds();
},1000);